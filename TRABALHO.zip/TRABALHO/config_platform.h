#ifndef __CONFIG_PLATFORM__
#define __CONFIG_PLATFORM__

extern void Init_Device(void);
void timerAndInterrups(void);

#endif //__CONFIG_PLATFORM__