#define B_TF3H 7
#define B_TR3 2
#define B_ET3 7


void timer2_init_auto(int i);
void timer3_init_auto(int i);
//void delay_s(unsigned char s);
void delay_ms(unsigned int ms);