#include <REG51F380.H>
#include "init_device.h"
#include <string.h>

sbit pb1 = P0^6;
sbit pb2 = P0^7;
sbit seg_dp = P2^7;


 
//chave por defeito	            	8			0			5			1
unsigned char default_key[4] = {0x80, 0xC0, 0x92, 0xF9};
 
//																	L			0			1			2			3			4			5			6			7			8			9
unsigned char digits_array[11] = {0xC7, 0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};


unsigned char button1pressed; //flags se os botoes sao clicados
unsigned char button2pressed;
unsigned int wrongkeycount;
 
code unsigned char coef[] = {127,137,148,158,168,177,186,194,202,209,215,220,225,228,231,232,233,232,231,228,225,220,215,209,202,194,186,177,168,158,148
,137,127,117,106,96,86,77,68,60,52,45,39,34,29,26,23,22,21,22,23,26,29,34,39,45,52,60,68,77,86,96,106,117}; 

/*********************************************************/
typedef enum ENUM_STATES {S1 = 0, S2, S3, S4, S5} e_states;

e_states state, nextstate;

/* function prototypes */
void state_1(void);
void state_2(void);
void state_3(void);
void state_4(void);
void state_5(void);


void timer2_init_auto(int reload){

	TMR2CN = 0;

	#define B_T2MH 5	

	CKCON &= ~((1 << B_T2MH));
	
	TMR2H = (reload) >> 8;
	TMR2L = (reload);

	TMR2RLH = (reload) >> 8;
	TMR2RLL = (reload);
	
}

void delay_10ms(){
		while(!TF2H);
		TF2H = 0;
}

void delay_1000ms(){
	unsigned int i = 0;
	while(i != 100){
		i++;
		delay_10ms();
	}
}
void delay_4000ms(){
	unsigned int i = 0;
	while(i != 400){
		i++;
		delay_10ms();
	}
}
void delay_9000ms(){
	unsigned int i = 0;
	while(i != 900){
		i++;
		delay_10ms();
	}
}
void delay_14000ms(){
	unsigned int i = 0;
	while(i != 1400){
		i++;
		delay_10ms();
	}
}
void delay_19000ms(){
	unsigned int i = 0;
	while(i != 1900){
		i++;
		delay_10ms();
	}
}
bit compare_vector(unsigned char v1[4], unsigned char v2[4]){
	return memcmp(v1, v2, 4) == 0;
}

//DEBOUNCE
unsigned int debounce(bit PB){
        char window = 0;  
        unsigned int j;
    for(j = 0; j < 8; j++) {
        window = (window << 1) | PB;
    }
    return window;
}

bit validate_key(unsigned char input_key[4]){	
		return compare_vector(default_key, input_key);		
}

void read_key(){
		unsigned char button1pressed; //flags se os botoes sao clicados
		unsigned char button2pressed;
		unsigned int digit_index;			//index dos digitos
		unsigned int index_input_key;	//index da key a ser lida
		unsigned char input_key[4];
		

	if(!debounce(pb2) && !button2pressed){
			button2pressed = 1; 
			input_key[index_input_key] = digits_array[digit_index];
			index_input_key++;
			digit_index = 0;
		}
		if(index_input_key == 4){
			if(validate_key(input_key)){
				index_input_key = 0;
				wrongkeycount = 0;
				nextstate = S2;
			}
			else{
				index_input_key = 0;
				nextstate = S3;
			}
		}
		if(debounce(pb2)){
			button2pressed = 0;
		}
	
    if(!debounce(pb1) && !button1pressed) {
			
			button1pressed = 1;            
      if (digit_index < 11) {
				digit_index++;
			}
			if (digit_index > 10){
        digit_index = 0;
			}
    }
		if(debounce(pb1)){
			button1pressed = 0;
		}

		P2 = digits_array[digit_index];
}

void errorhandling(){
		wrongkeycount++;
		if(wrongkeycount == 1){
			P2 = 0x86; // E
			delay_1000ms(); //diz que foi erro pelo E no display passado 1 segundo muda para C de close e espera mais 4 segundos num total de 5 segundos
			P2 = 0xC6; // C
			delay_4000ms();//wait 4 secs
			nextstate = S1;
		}
		if(wrongkeycount == 2){
			P2 = 0x86; // E
			delay_1000ms(); //diz que foi erro pelo E no display passado 1 segundo muda para C de close e espera mais 9 segundos
			P2 = 0xC6; // C
			delay_9000ms();//wait 9 secs
			nextstate = S1;
		}
		if(wrongkeycount == 3){
			P2 = 0x86; // E
			delay_1000ms(); //diz que foi erro pelo E no display passado 1 segundo muda para C de close e espera mais 14 segundos
			P2 = 0xC6; // C
			delay_14000ms();//wait 14 secs
			nextstate = S1;
		}
		if(wrongkeycount == 4){
			P2 = 0x86; // E
			delay_1000ms(); //diz que foi erro pelo E no display passado 1 segundo muda para C de close e espera mais 19 segundos
			P2 = 0xC6; // C
			delay_19000ms();//wait 19 secs
			nextstate = S1;
		}
		if(wrongkeycount == 5){
			nextstate = S4;
		}
}

void change_key(){//								O				P			C
		unsigned int open_change[3] = {0xA3 , 0x8C, 0xC6};
		unsigned int index;
		
		if(!debounce(pb2) && !button2pressed){
			button2pressed = 1;
			if(open_change[index] == 0x8C){
				nextstate = S5;
				index = 0;
			}
			if(open_change[index] == 0xC6){
				nextstate = S1;
				index = 0;
			}
		}
		
		if(debounce(pb2)){
			button2pressed = 0;
		}
		
		if(!debounce(pb1) && !button1pressed){
			
			
			button1pressed = 1;            
      if (index < 3){
				index++;
			}
			if (index > 2){
        index = 0;
			}
    }
		
		if(debounce(pb1)){
			button1pressed = 0;
		}

		P2 = open_change[index];
	
}
void set_key(){//									P			0			1			2			3			4			5			6			7			8			9
		unsigned int set_key[11] = {0x8C, 0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};
		unsigned int index;
		unsigned int index_new_key;
		
		if(!debounce(pb2) && !button2pressed){
			button2pressed = 1;
			default_key[index_new_key] = set_key[index];
			index_new_key++;
			index = 0;
		}
		
		if(index_new_key == 4){
			index_new_key = 0;
			nextstate = S1;
		}
		
		if(debounce(pb2)){
			button2pressed = 0;
		}
		
		if(!debounce(pb1) && !button1pressed){
			
			button1pressed = 1;            
      if (index < 11){
				index++;
			}
			if (index > 10){
        index = 0;
			}
    }
		
		if(debounce(pb1)){
			button1pressed = 0;
		}

		P2 = set_key[index];
}


/*********************************************************/	
//													close/locked  	open		error			alarm		set_key
void (*state_process [])(void) = {state_1, state_2, state_3, state_4, state_5};


void state_1(void){
		read_key();
		P1 = 0x10;
}
void state_2(void){
		change_key();
		P1 &= ~0x10;
}
void state_3(void){
		errorhandling();
}
void state_4(void){
		P2 = 0x88;
		P1 |= 0x80; //PIN P1.7 a 5V melhor que nada
}
void state_5(void){
		set_key();
		//mudar a key
}

/*********************************************************/
void encode_FSM(){
		state_process[state] ();
}

/*********************************************************/
void encode_FSM_switch(){
		switch (state) {
			case S1:
							state_1();
							break;
			case S2:
							state_2();
							break;
			case S3:
							state_3();
							break;
			case S4:
							state_4();
							break;
			default: break;
		}
}

/*********************************************************
 *    main function																	 		 *
 *********************************************************/
void main (void){
	
	Init_Device(); 
	
	timer2_init_auto(-40000);
	
	state = nextstate = S1;
	
	
	//Set by hardware when the Timer 2 high byte overflows from 0xFF to 0x00. In 16 bit 
	//mode, this will occur when Timer 2 overflows from 0xFFFF to 0x0000. 	
	TF2H = 0;	
	// Enable Flag Timer 2 Overflow
	ET2 = 1;
	// Timer 2 Run Control. Timer 2 is enabled by setting this bit to 1. 
	TR2 = 1;
		
		
	while (1) {
					
		// using an array of functions...
		encode_FSM();
		// using a switch case statement...
		//encode_FSM_switch();
		state = nextstate;
	}
}
