#ifndef __INIT_DEVICE__
#define __INIT_DEVICE__

typedef unsigned char uint8_t;
typedef unsigned int  uint16_t;

void Init_Device(void);

#endif

