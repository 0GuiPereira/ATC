#ifndef __CONFIG_PLATFORM__
#define __CONFIG_PLATFORM__

extern void Init_Device(void);

#endif //__CONFIG_PLATFORM__