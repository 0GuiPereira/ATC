void timer2_init_auto(int);
void delay_s(unsigned char s);