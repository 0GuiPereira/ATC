#include <REG51F380.H>
#include "init_device.h"
#include <string.h>

sbit pb1 = P0^6;
sbit pb2 = P0^7;


/* force the string to be stored in the program memory. 
 * Program (CODE) memory is read-only! 
 * const type also forces objects to be unchangeable */
 
//chave por defeito	            	8			0			5			1
unsigned char default_key[4] = {0x80, 0xC0, 0x92, 0xF9};
 
 //																										     0			1			2			3			4			5			6			7			8			9		
 // vetor numeros 0 a f unsigned char digitsarray[10] = { 0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};
unsigned char digits_array[11] = {0xC7, 0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};


unsigned char button1pressed; //flags se os botoes sao clicados
unsigned char button2pressed;
 
 //												L     O     C     E     A
//mudar dps para isto { 0xC7 ,0xA3, 0xC6, 0x86, 0x88 };
//code const char seg_data[] = { 0xF9, 0xA4, 0xB0, 0x99, 0x92 };
//code const uint8_t array_size = sizeof(seg_data)/sizeof(char);

/*********************************************************/
typedef enum ENUM_STATES {S1 = 0, S2, S3, S4, S5} e_states;

e_states state, nextstate;

/* function prototypes */
void state_1(void);
void state_2(void);
void state_3(void);
void state_4(void);
void state_5(void);

bit compara_vetor(unsigned char v1[4], unsigned char v2[4]){
	return memcmp(v1, v2, 4) == 0;
}

//DEBOUNCE
unsigned int debounce(bit PB){
        char window = 0;  
        unsigned int j;
    for(j = 0; j < 8; j++) {
        window = (window << 1) | PB;
    }
    return window;
}

void configure_timer(){
		TMOD |= 0x01; // 16bits
    TH0 = 0x4C;  // Set the high byte of the initial value for 0.5-second delay
    TL0 = 0x00;  // Set the low byte of the initial value

    // Enable Timer 0 interrupt
    ET0 = 1;
    EA = 1;

    // Start Timer 0
    TR0 = 1;
}

void timer_error(unsigned int value){

    TH0 = value;
    TL0 = 0x00;
		
		P2 ^= 0x80;

    //nextstate = S3;
}

bit validate_key(unsigned char input_key[4]){
		//chave por defeito	            	8			0			5			1
		//unsigned char default_key[4] = {0x80, 0xC0, 0x92, 0xF9};
		
		return compara_vetor(default_key, input_key);

		//diplay os numeros e pb2 igual a enter P2 = {0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};
		
}

void read_key(){
		unsigned char button1pressed; //flags se os botoes sao clicados
		unsigned char button2pressed;
		unsigned int digit_index;
		unsigned int index_input_key;
		unsigned char input_key[4];
		unsigned int wrongkeycount;
		

	if(!pb2 && !button2pressed){
			button2pressed = 1; 
			input_key[index_input_key] = digits_array[digit_index];
			index_input_key++;
			digit_index = 0;
		}
		if(index_input_key == 4){
			if(validate_key(input_key)){
				nextstate = S2;
			}
			else{
				index_input_key = 0;
				nextstate = S3;
			}
		}
		if(pb2){
			button2pressed = 0;
		}
	
    if(!pb1 && !button1pressed) {
			
			button1pressed = 1;            
      if (digit_index < 11) {
				digit_index++;
			}
			if (digit_index > 10){
        digit_index = 0;
			}
    }
		if(pb1){
			button1pressed = 0;
		}

		P2 = digits_array[digit_index];
}

//apagar depois
void simple_delay(){
	unsigned int i;
	for (i = 0; i<65000;i++){
	}
}

void errorhandling(){
		unsigned int wrongkeycount;
		wrongkeycount++;
		if(wrongkeycount == 1){
			//P2 = 0x86; // E
			//wait 1 secs diz que foi erro pelo E no display passado 1 segundo muda para C de close
			//P2 = 0xC6; // C
			//wait 4 secs
			timer_error(0x26);
			nextstate = S3;
		}
		if(wrongkeycount == 2){
			P2 = 0x86; // E
			//wait 10 secs
			nextstate = S1;
		}
		if(wrongkeycount == 3){
			P2 = 0x86; // E
			//wait 15 secs
			nextstate = S1;
		}
		if(wrongkeycount == 4){
			P2 = 0x86; // E
			//wait 20 secs
			nextstate = S1;
		}
		if(wrongkeycount == 5){
			nextstate = S4;
		}
}

void change_key(){
		unsigned int open_change[2] = {0xA3 , 0x8C};
		unsigned int index;
		
		if(!pb2 && !button2pressed){
			button2pressed = 1;
			if(open_change[index] == 0x8C){
				nextstate = S5;
				index = 0;
			}
		}
		
		if(pb2){
			button2pressed = 0;
		}
		
		if(!pb1 && !button1pressed){
			
			timer_error(0x26);
			
			button1pressed = 1;            
      if (index < 2){
				index++;
			}
			if (index > 1){
        index = 0;
			}
    }
		
		if(pb1){
			button1pressed = 0;
		}

		P2 = open_change[index];
	
}
void set_key(){
		unsigned int set_key[11] = {0x8C, 0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};
		unsigned int index;
		unsigned int index_new_key;
		
		if(!pb2 && !button2pressed){
			button2pressed = 1;
			default_key[index_new_key] = set_key[index];
			index_new_key++;
			index = 0;
		}
		
		if(index_new_key == 4){
			index_new_key = 0;
			nextstate = S1;
		}
		
		if(pb2){
			button2pressed = 0;
		}
		
		if(!pb1 && !button1pressed){
			
			button1pressed = 1;            
      if (index < 11){
				index++;
			}
			if (index > 10){
        index = 0;
			}
    }
		
		if(pb1){
			button1pressed = 0;
		}

		P2 = set_key[index];
}


/*********************************************************/	
//																locked  	open		close			alarm		set_key
void (*state_process [])(void) = {state_1, state_2, state_3, state_4, state_5};


void state_1(void){
		read_key();
		//P1^4 = 5v
}
void state_2(void){
		change_key();
		//P1^4 = 0v
}
void state_3(void){
		//P2 = 0xC6;
		errorhandling();
}
void state_4(void){
		//P2 = 0x88;
		//onda quadratica
}
void state_5(void){
		set_key();
		//mudar a key
}

/*********************************************************/
void encode_FSM(){
		state_process[state] ();
}

/*********************************************************/
void encode_FSM_switch(){
		switch (state) {
			case S1:
							state_1();
							break;
			case S2:
							state_2();
							break;
			case S3:
							state_3();
							break;
			case S4:
							state_4();
							break;
			default: break;
		}
}

/*********************************************************
 *    main function																	 		 *
 *********************************************************/
void main (void){
	
	Init_Device(); 

	state = nextstate = S1;
	

	
	while (1) {
			
		// using an array of functions...
		encode_FSM();
		// using a switch case statement...
		//encode_FSM_switch();
		state = nextstate;
	}
}
